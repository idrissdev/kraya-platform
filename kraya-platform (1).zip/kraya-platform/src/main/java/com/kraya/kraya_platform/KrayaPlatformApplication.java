package com.kraya.kraya_platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KrayaPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(KrayaPlatformApplication.class, args);
	}

}
