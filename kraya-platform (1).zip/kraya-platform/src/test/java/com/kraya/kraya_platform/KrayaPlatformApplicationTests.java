package com.kraya.kraya_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KrayaPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
